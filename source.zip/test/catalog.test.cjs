'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {safeUrl,exactMatch,entry,generate}=require('../src/catalog.cjs');
const fixture=(extra={})=>({source:'Filmix',type:'movie',title:'Fixture Movie',originalTitle:'Fixture Movie',year:2020,imdbId:'tt1234567',tmdbId:'123',poster:'https://image.tmdb.org/t/p/w500/fixture.jpg',sourceUrl:'https://filmix.fm/films/fixture.html',checkedAt:'2026-10-17T09:00:00Z',officialMetaUrl:'https://catalog.nuvio.tv/meta/movie/tt1234567.json',catalogYear:2020,mappingStatus:'exact-official-title-year-type',...extra});
test('only exact title, release year and content type produce an unambiguous match',()=>{
 const candidates=[{id:'tt1234567',type:'movie',name:'Fixture Movie',releaseInfo:'2020'},{id:'tt2234567',type:'movie',name:'Fixture Movie',releaseInfo:'1990'},{id:'tt3234567',type:'series',name:'Fixture Movie',releaseInfo:'2020'}];
 assert.equal(exactMatch(fixture(),candidates).id,'tt1234567');
 assert.equal(exactMatch(fixture({title:'Fixture',originalTitle:''}),candidates),null);
 assert.equal(exactMatch(fixture({year:2021}),candidates),null);
 assert.equal(exactMatch(fixture(),candidates.concat({id:'tt4234567',type:'movie',name:'Fixture Movie',releaseInfo:'2020'})),null);
});
test('normalization accepts punctuation and Turkish accents without fuzzy title substitution',()=>{
 assert.ok(exactMatch({type:'tv',title:'Şahsiyet',year:2018},[{id:'tt7923832',type:'series',name:'Sahsiyet',releaseInfo:'2018-'}]));
 assert.equal(exactMatch({type:'tv',title:'Dark Matter',year:2024},[{id:'tt4159076',type:'series',name:'Dark Matter',releaseInfo:'2015-2017'}]),null);
});
test('unmapped, stale-cache, challenged and incompatible episode entries are omitted',()=>{
 for(const extra of [{mappingStatus:'mapping-request-failed'},{cachedOnly:true},{currentCatalogBlocked:true},{episodeRouteCompatible:false},{catalogYear:2019},{imdbId:null},{source:'Rezka'}])assert.equal(entry(fixture(extra)),null);
});
test('metadata IDs and type must agree with the official metadata endpoint',()=>{
 assert.equal(entry(fixture({officialMetaUrl:'https://catalog.nuvio.tv/meta/series/tt1234567.json'})),null);
 assert.equal(entry(fixture({officialMetaUrl:'https://catalog.nuvio.tv/meta/movie/tt7654321.json'})),null);
 assert.equal(entry(fixture({title:'<script>untrusted</script>'})),null);
});
test('source provenance is scoped to the verified website and title quotes are display-safe',()=>{
 assert.equal(entry(fixture({sourceUrl:'https://unrelated.test/fixture.html'})),null);
 assert.equal(entry(fixture({originalTitle:'<script>bad</script>'})),null);
 const item=entry(fixture({title:'The "Movie"\'s Title'}));
 assert.equal(item.preview.name,'The ”Movie”’s Title');
 assert.ok(!/["']/.test(item.preview.name));
});
test('public HTTPS URLs reject credentials, local network addresses and control characters',()=>{
 for(const value of ['http://cdn.test/a.jpg','https://me:secret@cdn.test/a.jpg','https://127.0.0.1/a','https://192.168.1.1/a','https://localhost/a','https://cdn.test/a?access_token=secret','https://cdn.test/a\n.jpg'])assert.equal(safeUrl(value),'');
 assert.equal(safeUrl('https://image.tmdb.org/t/p/w500/a.jpg'),'https://image.tmdb.org/t/p/w500/a.jpg');
});
test('one companion manifest adds website rows and preserves global IMDb identity',()=>{
 const files=generate([fixture(),fixture({source:'DiziBOX',type:'tv',title:'Fixture Series',imdbId:'tt2234567',sourceUrl:'https://www.dizibox.live/diziler/fixture/',officialMetaUrl:'https://catalog.nuvio.tv/meta/series/tt2234567.json'})],'2026-10-17T10:00:00Z');
 assert.deepEqual(files['manifest.json'].resources,['catalog']);
 assert.deepEqual(files['manifest.json'].catalogs.map(x=>x.id),['filmix-movies','dizibox-series']);
 assert.ok(files['manifest.json'].catalogs.every(x=>!x.extra));
 assert.equal(files['catalog/series/dizibox-series.json'].metas[0].id,'tt2234567');
 assert.equal(files['catalog/series/dizibox-series.json'].metas[0].type,'series');
});
test('duplicate IMDb IDs preserve earliest website order and terminal pagination is empty',()=>{
 const files=generate([fixture(),fixture({title:'Duplicate'}),fixture({title:'Second',imdbId:'tt2234567',officialMetaUrl:'https://catalog.nuvio.tv/meta/movie/tt2234567.json'})],'2026-10-17T10:00:00Z');
 assert.deepEqual(files['catalog/movie/filmix-movies.json'].metas.map(x=>x.name),['Fixture Movie','Second']);
 assert.deepEqual(files['catalog/movie/filmix-movies/skip=2.json'].metas,[]);
 assert.equal(files['snapshot.json'].totalCards,2);
});
test('empty rows are not advertised and empty input fails instead of publishing a blank catalog',()=>{
 assert.throws(()=>generate([], '2026-10-17T10:00:00Z'),/No verified/);
 const files=generate([fixture()],'2026-10-17T10:00:00Z');
 assert.equal(files['manifest.json'].catalogs.length,1);
 assert.equal(files['catalog/series/seasonvar-series.json'],undefined);
});
