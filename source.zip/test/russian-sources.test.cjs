'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const sources = require('../tools/russian/russian-sources.cjs');

test('Filmix collector reads only public listing metadata and preserves the source order', async () => {
  const calls = [];
  const rows = await sources.collectFilmix({json: async url => {
    calls.push(url);
    return {proof:{fetchedAt:'2026-10-17T00:00:00Z'},data:{has_next_page:false,items:[{id:8,title:'Сериал',original_name:'Example Show',year:2022,last_season:3,url:'https://filmix.fm/seria/8-example.html',poster:'https://cdn.filmix.tv/poster.jpg'},{id:9,title:'Фильм',original_name:'Example Movie',year:2024,url:'https://filmix.fm/film/9-example.html'}]}};
  }});
  assert.equal(calls.length,1);
  assert.equal(calls[0],'https://api.filmix.tv/api-fx/list?limit=48&page=1');
  assert.deepEqual(rows.map(row => [row.sourceId,row.type,row.listingPosition]),[['8','series',1],['9','movie',2]]);
  assert.deepEqual(rows[0].externalIds,{});
});

function page(original, year, season, firstLink) {
  return '<h1 class="pgs-sinfo-title">Сериал Название ' + season + ' сезон онлайн</h1>Оригинал: <span>' + original + '</span>Вышел: <span>' + year + '</span>' + (firstLink ? '<div class="pgs-seaslist"><a href="' + firstLink + '">1 сезон</a></div>' : '');
}

test('Seasonvar metadata uses the linked first season year for the same original title', async () => {
  const row = {sourceUrl:'https://seasonvar.ru/serial-2-example.html'};
  await sources.enrichSeasonvar([row],{get:async url => ({fetchedAt:'2026-10-17T00:00:00Z',body:url.includes('serial-2-') ? page('Example Show',2026,4,'/serial-1-example.html') : page('Example Show',2022,1)})});
  assert.equal(row.year,2022);
  assert.equal(row.firstSeasonUrl,'https://seasonvar.ru/serial-1-example.html');
});

test('Seasonvar never borrows the first season year from a differently titled linked page', async () => {
  const row = {sourceUrl:'https://seasonvar.ru/serial-2-example.html'};
  await sources.enrichSeasonvar([row],{get:async url => ({body:url.includes('serial-2-') ? page('Example Show',2026,4,'/serial-1-example.html') : page('Unrelated Show',2022,1)})});
  assert.equal(row.year,null);
});

test('mapper accepts one exact original-title/year/type match and validates the detail ID', async () => {
  const row = {originalTitle:'Example Movie',year:2024,type:'movie'};
  const meta = {id:'tt12345678',name:'Example Movie',releaseInfo:'2024',type:'movie',links:[{url:'https://www.themoviedb.org/movie/123'}]};
  await sources.mapRows([row],{json:async url => ({proof:{fetchedAt:'2026-10-17T00:00:00Z'},data:url.includes('/catalog/') ? {metas:[meta,{...meta,id:'tt87654321',releaseInfo:'2004'}]} : {meta}})});
  assert.equal(row.mapping.status,'mapped');
  assert.equal(row.externalIds.imdb,'tt12345678');
  assert.equal(row.externalIds.tmdb,'123');
});

test('mapper excludes wrong-year, wrong-type, ambiguous, and detail-conflict results', async () => {
  const meta = {id:'tt12345678',name:'Example',releaseInfo:'2024',type:'movie'};
  for (const results of [[{...meta,releaseInfo:'2004'}],[{...meta,type:'series'}],[meta,{...meta,id:'tt87654321'}]]) {
    const row = {originalTitle:'Example',year:2024,type:'movie'};
    await sources.mapRows([row],{json:async () => ({data:{metas:results}})});
    assert.equal(row.mapping.status,'unmapped');
    assert.equal(row.externalIds,undefined);
  }
  const row = {originalTitle:'Example',year:2024,type:'movie'};
  await sources.mapRows([row],{json:async url => ({data:url.includes('/catalog/') ? {metas:[meta]} : {meta:{...meta,id:'tt87654321'}}})});
  assert.equal(row.mapping.status,'unmapped');
  assert.equal(row.mapping.reason,'detail-metadata-conflict');
});
