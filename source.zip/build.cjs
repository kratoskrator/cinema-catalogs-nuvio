'use strict';
const fs=require('node:fs');const path=require('node:path');
const {generate}=require('./src/catalog.cjs');
const input=JSON.parse(fs.readFileSync(path.join(__dirname,'data/records.json'),'utf8'));
const files=generate(input.records,input.generatedAt,{version:require('./package.json').version,sourceStatus:input.sourceStatus});
let changed=0;
for(const [name,data] of Object.entries(files)) {
  const target=path.join(__dirname,...name.split('/'));
  const body=JSON.stringify(data,null,2)+'\n';
  if(Buffer.byteLength(body)>=1024*1024)throw new Error('Catalog response too large: '+name);
  if(process.argv.includes('--check')) {
    if(!fs.existsSync(target)||fs.readFileSync(target,'utf8')!==body)throw new Error('Generated file is stale: '+name);
  }else{fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,body);}
  changed++;
}
console.log(JSON.stringify({files:changed,rows:files['manifest.json'].catalogs.length,cards:files['snapshot.json'].totalCards,checked:process.argv.includes('--check')}));
