'use strict';
const ROWS = [
  {source:'Filmix',type:'movie',id:'filmix-movies',name:'Filmix — Movies'},
  {source:'Filmix',type:'series',id:'filmix-series',name:'Filmix — Series'},
  {source:'Seasonvar',type:'series',id:'seasonvar-series',name:'Seasonvar — Series'},
  {source:'DiziBOX',type:'series',id:'dizibox-series',name:'DiziBOX — Series'},
  {source:'DiziYou',type:'series',id:'diziyou-series',name:'DiziYou — Series'}
];
const SOURCE_HOSTS={Filmix:['filmix.fm','filmix.gg','filmix.tv'],Seasonvar:['seasonvar.ru'],DiziBOX:['www.dizibox.live','dizibox.live'],DiziYou:['www.diziyou.one','diziyou.one']};
function displayTitle(value) {
  return String(value||'').trim().replace(/"/g,'”').replace(/'/g,'’');
}
function safeUrl(value) {
  try {
    const url = new URL(String(value||''));
    if(url.protocol!=='https:' || url.username || url.password || /[\s\\\x00-\x1f\x7f]/.test(value))return '';
    if(!/^[a-z0-9.-]+$/i.test(url.hostname) || !url.hostname.includes('.') || /(?:^|\.)localhost\.?$/i.test(url.hostname))return '';
    if(/^(?:127\.|10\.|192\.168\.|169\.254\.|0\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(url.hostname))return '';
    for(const key of url.searchParams.keys())if(/^(?:token|access_token|api_key|authorization|hash|password|session|cookie)$/i.test(key))return '';
    return url.href;
  }catch{return '';}
}
function normalizeTitle(value) {
  return String(value||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ı/g,'i').replace(/ё/g,'е').replace(/&/g,' and ').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
}
function exactMatch(record, candidates) {
  const type=record.type==='tv'?'series':record.type;
  const titles=[record.originalTitle,record.title].filter(Boolean).map(normalizeTitle);
  const wantedYear=Number(record.year);
  if(!['movie','series'].includes(type)||!Number.isInteger(wantedYear)||wantedYear<1880||wantedYear>2200)return null;
  const found=new Map();
  for(const item of candidates||[]) {
    const year=Number((/\b(\d{4})\b/.exec(String(item.releaseInfo||item.year||''))||[])[1]);
    if(item.type===type && /^tt\d{7,10}$/.test(item.id||'') && titles.includes(normalizeTitle(item.name)) && year===wantedYear)found.set(item.id,item);
  }
  return found.size===1?[...found.values()][0]:null;
}
function entry(record) {
  if(!record || record.cachedOnly || record.currentCatalogBlocked || record.episodeRouteCompatible===false)return null;
  const type=record.type==='tv'?'series':record.type;
  if(!ROWS.some(row=>row.source===record.source&&row.type===type))return null;
  const id=record.imdbId||record.externalIds&&record.externalIds.imdb;
  const mapped=record.mapping&&record.mapping.status==='mapped'||record.mappingStatus==='exact-official-title-year-type'||record.mappingStatus==='published-id';
  const checkedAt=record.checkedAt||record.fetchedAt;
  const year=Number(record.year);
  const poster=safeUrl(record.officialPoster||record.officialMeta&&record.officialMeta.poster||record.poster);
  const sourceUrl=safeUrl(record.sourceUrl);
  const officialMetaUrl=safeUrl(record.officialMetaUrl||record.mapping&&record.mapping.metaUrl);
  if(!mapped||!/^tt\d{7,10}$/.test(id||'')||!Number.isInteger(year)||year<1880||year>2200||!poster||!sourceUrl||!checkedAt||!Number.isFinite(Date.parse(checkedAt)))return null;
  if(!(SOURCE_HOSTS[record.source]||[]).includes(new URL(sourceUrl).hostname))return null;
  if(officialMetaUrl!=='https://catalog.nuvio.tv/meta/'+type+'/'+id+'.json')return null;
  const canonicalYear=Number(record.catalogYear||record.mapping&&record.mapping.canonicalYear||year);
  if(canonicalYear!==year)return null;
  const name=displayTitle(record.title||record.catalogName||record.officialMeta&&record.officialMeta.name);
  if(!name||name.length>240||/[<>\x00-\x1f]/.test(name))return null;
  const original=displayTitle(record.originalTitle);
  if(/[<>\x00-\x1f]/.test(original)||original.length>240)return null;
  return {
    source:record.source,sourceUrl,checkedAt,listingPosition:Number(record.listingPosition)||0,
    originalTitle:original,tmdbId:String(record.tmdbId||record.externalIds&&record.externalIds.tmdb||''),
    mappingMethod:record.mappingStatus||record.mapping&&record.mapping.method,
    preview:{id,type,name,poster,posterShape:'poster',releaseInfo:String(year),
      description:'Listed on '+record.source+'. Website listing checked '+checkedAt.slice(0,10)+'.'+(original&&original!==name?' Original title: '+original+'.':'')+' Playback availability is checked when you select a source.',
      links:[{name:record.source,category:'website',url:sourceUrl}]}
  };
}
function generate(records, generatedAt, options={}) {
  if(!Number.isFinite(Date.parse(generatedAt)))throw new Error('A valid generation timestamp is required');
  const version=options.version||'1.0.0';
  if(!/^\d+\.\d+\.\d+$/.test(version))throw new Error('A valid catalog version is required');
  const entries=(records||[]).map(entry).filter(Boolean);
  const files={};const rows=[];const provenance=[];
  for(const row of ROWS) {
    const seen=new Set();
    const selected=entries.filter(item=>item.source===row.source&&item.preview.type===row.type).filter(item=>!seen.has(item.preview.id)&&seen.add(item.preview.id)).slice(0,100);
    if(!selected.length)continue;
    const metas=selected.map(item=>item.preview);
    rows.push({type:row.type,id:row.id,name:row.name});
    files['catalog/'+row.type+'/'+row.id+'.json']={metas,cacheMaxAge:3600};
    files['catalog/'+row.type+'/'+row.id+'/skip='+metas.length+'.json']={metas:[],cacheMaxAge:3600};
    provenance.push({source:row.source,type:row.type,catalogId:row.id,count:metas.length,entries:selected.map(({preview,...item})=>({...item,id:preview.id,name:preview.name,year:Number(preview.releaseInfo)}))});
  }
  if(!rows.length)throw new Error('No verified website titles can be published');
  const manifest={id:'org.kratoskrator.cinema.catalogs',version,name:'Cinema Catalogs — Turkish & Russian Sites',description:'Website-specific browsing rows from Filmix, Seasonvar, DiziBOX and DiziYou. Snapshot '+generatedAt.slice(0,10)+'. Keep the official Nuvio catalog for current metadata and search.',resources:['catalog'],types:['movie','series'],idPrefixes:['tt'],catalogs:rows,behaviorHints:{adult:false,p2p:false,configurable:false}};
  files['manifest.json']=manifest;
  files['snapshot.json']={generatedAt,mode:'website-listing-snapshot',searchProvider:'existing official Nuvio catalog',entries:provenance,totalCards:provenance.reduce((sum,row)=>sum+row.count,0),excludedSources:[{source:'Rezka',reason:'Browser verification and browser site-safety access restrictions prevented catalog verification.'},{source:'HDFilmCehennemi',reason:'Current homepage request returned an access challenge; cached records were excluded.'}]};
  if(options.sourceStatus)files['snapshot.json'].sourceStatus=options.sourceStatus;
  return files;
}
module.exports={ROWS,safeUrl,normalizeTitle,exactMatch,entry,generate};
