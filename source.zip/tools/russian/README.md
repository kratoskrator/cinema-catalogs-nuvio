# Russian website catalog collector

Run with Node.js 20 or newer:

```sh
node russian-sources.cjs ./catalog-data
```

This standalone script uses only Node built-ins and normal anonymous HTTPS requests. It collects two FilmixTV public metadata pages and the Seasonvar homepage, preserving the websites' listing positions. It examines at most 20 Filmix movies, 20 Filmix series and 40 Seasonvar entries. Seasonvar start years come from the site's linked first-season page.

It maps a title only when Nuvio's public metadata search and detail agree on the exact normalized original title, first release year and media type, with one unambiguous IMDb ID. It also records TMDB links when published by that metadata endpoint. Unmapped, conflicting and unavailable results retain an exclusion reason; do not publish them as guessed matches. Seasonvar may list several seasons of one show: deduplicate IMDb IDs within a catalog row, keeping the earliest source position.

Output files:

- `filmix-records.json` and `seasonvar-records.json`: source snapshots, at most 100 records each.
- `filmix-mapped.json` and `seasonvar-mapped.json`: examined records with provenance, canonical IDs and mapping status.
- `summary.json`: counts and snapshot timestamp.
- `cache/`: public metadata responses reused by repeated runs. Start with a fresh output directory when a fresh website snapshot is wanted. Keep this cache out of the published addon/source archive.

The collector spaces request starts by at least 1.2 seconds and runs at most two operations concurrently. It stops using a host for that run when it receives an access restriction, rate limit or verification page. It does not execute site scripts, solve verification, request media, use accounts or require Nuvio's TV networking service.

Catalog membership records what the websites list. It does not establish that every episode, translation or quality is currently playable.
