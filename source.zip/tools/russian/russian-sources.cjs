'use strict';
// Public, account-free catalog metadata collector. Node.js 20+; no dependencies.
// It never requests video playlists, account endpoints, or site challenges.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_BYTES = 1024 * 1024;
const MAX_RECORDS = 100;
const HOSTS = new Set(['api.filmix.tv', 'seasonvar.ru', 'catalog.nuvio.tv']);
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function entities(value) {
  return String(value || '').replace(/&#(x[\da-f]+|\d+);|&(amp|quot|apos|lt|gt|nbsp);/gi, (all, code, name) => {
    if (code) return String.fromCodePoint(code[0].toLowerCase() === 'x' ? parseInt(code.slice(1), 16) : Number(code));
    return {amp:'&',quot:'"',apos:"'",lt:'<',gt:'>',nbsp:' '}[name.toLowerCase()];
  });
}
function text(value) { return entities(String(value || '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim(); }
function normalize(value) { return text(value).toLowerCase().replace(/ё/g, 'е').replace(/[^a-z0-9а-я]+/g, ' ').trim(); }
function attr(tag, name) {
  const match = new RegExp('(?:^|\\s)' + name + '\\s*=\\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|([^\\s>]+))', 'i').exec(tag || '');
  return match ? entities(match[1] !== undefined ? match[1] : match[2] !== undefined ? match[2] : match[3]) : '';
}
function absolute(value, base) { try { const url = new URL(entities(value), base); return url.protocol === 'https:' ? url.href : ''; } catch { return ''; } }
function year(value) { const match = String(value || '').match(/(?:19|20)\d{2}/); return match ? Number(match[0]) : null; }
function metaYear(meta) { return year(meta.releaseInfo || meta.year || meta.released); }
function seasonNumber(value) { const match = /(?:^|\s)(\d+)\s*сезон(?:\s|$|[<(])/i.exec(text(value)); return match ? Number(match[1]) : 1; }

function createClient(cacheDirectory, options = {}) {
  fs.mkdirSync(cacheDirectory, {recursive:true});
  const requestGap = Math.max(1120, Number(options.requestGap) || 1200);
  const blocked = new Set();
  let queue = Promise.resolve(), lastStarted = 0;
  async function pace() {
    const next = queue.then(async () => {
      const wait = Math.max(0, lastStarted + requestGap - Date.now());
      if (wait) await new Promise(resolve => setTimeout(resolve, wait));
      lastStarted = Date.now();
    });
    queue = next;
    await next;
  }
  async function get(url) {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password || !HOSTS.has(parsed.hostname)) throw new Error('Unsupported public metadata URL');
    const cacheFile = path.join(cacheDirectory, crypto.createHash('sha256').update(url).digest('hex') + '.json');
    if (fs.existsSync(cacheFile)) {
      const cached = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      if (cached.status === 200 && !cached.challenge) return cached;
    }
    if (blocked.has(parsed.hostname)) throw new Error('Public metadata site unavailable for this run');
    await pace();
    const response = await fetch(url, {method:'GET',redirect:'error',signal:AbortSignal.timeout(15000),headers:{'User-Agent':UA,Accept:'application/json, text/html, */*','Accept-Language':'ru-RU,ru;q=0.9,en;q=0.8'}});
    const chunks = []; let length = 0;
    if (response.body) {
      const reader = response.body.getReader();
      try { while (true) { const part = await reader.read(); if (part.done) break; length += part.value.byteLength; if (length > MAX_BYTES) throw new Error('Public metadata exceeds size limit'); chunks.push(Buffer.from(part.value)); } }
      catch (error) { await reader.cancel().catch(() => {}); throw error; }
    }
    const body = Buffer.concat(chunks).toString('utf8');
    const challenge = /anubis_challenge|cf-browser-verification|<title[^>]*>\s*(?:Just a moment|Attention Required|Проверяем, что вы не бот)/i.test(body);
    const result = {requested:url,finalUrl:response.url,status:response.status,fetchedAt:new Date().toISOString(),challenge,body};
    fs.writeFileSync(cacheFile, JSON.stringify(result));
    if (challenge || [401,403,429,451].includes(response.status)) blocked.add(parsed.hostname);
    if (!response.ok || challenge) throw new Error('Public metadata site unavailable for this run');
    return result;
  }
  return {get, async json(url) { const result = await get(url); return {data:JSON.parse(result.body),proof:result}; }};
}

async function pool(rows, handler) {
  // At most two operations are active. The client also spaces network starts.
  for (let index = 0; index < rows.length; index += 2) await Promise.all(rows.slice(index, index + 2).map(handler));
}

async function collectFilmix(client) {
  const rows = [], seen = new Set();
  for (let page = 1; page <= 2; page++) {
    const listingUrl = 'https://api.filmix.tv/api-fx/list?limit=48&page=' + page;
    const {data,proof} = await client.json(listingUrl);
    if (!Array.isArray(data.items)) throw new Error('Filmix public listing format changed');
    for (const item of data.items.slice(0, 48)) {
      if (!/^\d+$/.test(String(item.id || '')) || seen.has(item.id) || rows.length >= MAX_RECORDS) continue;
      seen.add(item.id);
      rows.push({source:'Filmix',sourceId:String(item.id),type:item.last_season || item.last_episode || /\/(?:seria|multser)\//.test(item.url || '') ? 'series' : 'movie',title:text(item.title),originalTitle:text(item.original_name),year:year(item.year),poster:absolute(item.poster,listingUrl),sourceUrl:absolute(item.url,listingUrl),externalIds:{},genres:(item.genres || []).map(item => text(item.name)).slice(0,12),listingPosition:rows.length+1,listingPage:page,listingUrl,fetchedAt:proof.fetchedAt});
    }
    if (data.has_next_page === false) break;
  }
  return rows;
}

function seasonvarPage(html, pageUrl) {
  html = String(html || '').replace(/<!--[\s\S]*?-->/g, '');
  const heading = /<h1\b[^>]*class=["'][^"']*\bpgs-sinfo-title\b[^"']*["'][^>]*>([\s\S]*?)<\/h1\s*>/i.exec(html);
  const original = /Оригинал\s*:\s*<span\b[^>]*>([\s\S]*?)<\/span\s*>/i.exec(html);
  const release = /Вышел\s*:\s*<span\b[^>]*>\s*((?:19|20)\d{2})\s*<\/span\s*>/i.exec(html);
  const poster = /<meta\b[^>]*property="og:image"[^>]*content="([^"]+)"/i.exec(html);
  const section = /<div\b[^>]*class=["'][^"']*\bpgs-seaslist\b[^"']*["'][^>]*>([\s\S]*?)<\/div\s*>/i.exec(html);
  const seasons = {}, links = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi;
  let match;
  if (section) while ((match = links.exec(section[1]))) {
    const url = absolute(attr(match[1], 'href'), 'https://seasonvar.ru/');
    if (/^https:\/\/seasonvar\.ru\/serial-\d+-[^?#]+\.html$/.test(url)) seasons[seasonNumber(match[2])] = url;
  }
  const season = seasonNumber(heading ? heading[1] : '');
  if (!Object.keys(seasons).length && heading) seasons[season] = pageUrl;
  return {originalTitle:original ? text(original[1]) : '',year:release ? Number(release[1]) : null,season,seasons,poster:poster ? absolute(poster[1],pageUrl) : ''};
}

async function collectSeasonvar(client) {
  const listingUrl = 'https://seasonvar.ru/';
  const proof = await client.get(listingUrl);
  const rows = [], seen = new Map(), anchors = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi;
  let match;
  while ((match = anchors.exec(proof.body))) {
    const href = attr(match[1], 'href'), id = /^\/serial-(\d+)-[^?#]+\.html$/.exec(href);
    if (!id) continue;
    const news = /<div\b[^>]*class="news_n"[^>]*>([\s\S]*?)<\/div\s*>/i.exec(match[2]);
    const title = text(news ? news[1] : match[2]).replace(/\s*\(\d+\s+сезон\).*$/i,'').replace(/\s*\d+(?:-\d+)?\s+серия.*$/i,'').trim();
    const image = /<img\b([^>]*)>/i.exec(match[2]);
    const poster = image ? absolute(attr(image[1], 'src') || attr(image[1], 'data-src'), listingUrl) : '';
    if (seen.has(id[1])) { if (poster) seen.get(id[1]).poster = poster; continue; }
    if (!title) continue;
    const row = {source:'Seasonvar',sourceId:id[1],type:'series',title,originalTitle:'',year:null,poster,sourceUrl:listingUrl.slice(0,-1)+href,externalIds:{},listingPosition:rows.length+1,listingUrl,fetchedAt:proof.fetchedAt};
    rows.push(row); seen.set(id[1], row);
  }
  return rows.slice(0, MAX_RECORDS);
}

async function enrichSeasonvar(rows, client) {
  await pool(rows, async row => {
    try {
      const result = await client.get(row.sourceUrl), page = seasonvarPage(result.body,row.sourceUrl);
      row.originalTitle = page.originalTitle; row.year = page.year; row.season = page.season; row.detailFetchedAt = result.fetchedAt;
      if (page.poster) row.poster = page.poster;
      const firstUrl = page.seasons[1];
      if (firstUrl && firstUrl !== row.sourceUrl) {
        const first = await client.get(firstUrl), initial = seasonvarPage(first.body,firstUrl);
        if (initial.season === 1 && normalize(initial.originalTitle) === normalize(page.originalTitle)) {
          row.originalTitle = initial.originalTitle; row.year = initial.year; row.firstSeasonUrl = firstUrl; row.firstSeasonFetchedAt = first.fetchedAt;
        } else row.year = null;
      } else if (page.season > 1) row.year = null;
    } catch { row.detailUnavailable = true; }
  });
  return rows;
}

async function mapRows(rows, client) {
  await pool(rows, async row => {
    row.mapping = {status:'unmapped'};
    if (!row.originalTitle || !row.year) { row.mapping.reason = 'missing-original-title-or-first-release-year'; return; }
    const type = row.type, catalog = type === 'movie' ? 'popular-movies' : 'popular-series';
    const searchUrl = 'https://catalog.nuvio.tv/catalog/' + type + '/' + catalog + '/search=' + encodeURIComponent(row.originalTitle) + '.json';
    try {
      const response = await client.json(searchUrl), wanted = normalize(row.originalTitle);
      const exact = (response.data.metas || []).slice(0,100).filter(meta => meta.type === type && normalize(meta.name) === wanted && metaYear(meta) === Number(row.year) && /^tt\d{7,10}$/.test(meta.id || ''));
      const candidates = [...new Map(exact.map(meta => [meta.id, meta])).values()];
      if (candidates.length !== 1) { row.mapping = {status:'unmapped',reason:candidates.length ? 'ambiguous-exact-match' : 'no-exact-original-title-year-type-match',searchUrl}; return; }
      const metaUrl = 'https://catalog.nuvio.tv/meta/' + type + '/' + candidates[0].id + '.json';
      const detail = await client.json(metaUrl), meta = detail.data.meta;
      if (!meta || meta.id !== candidates[0].id || meta.type !== type || normalize(meta.name) !== wanted || metaYear(meta) !== Number(row.year)) { row.mapping.reason = 'detail-metadata-conflict'; return; }
      const tmdb = (meta.links || []).map(link => String(link.url || '')).map(link => new RegExp('^https?://(?:www\\.)?themoviedb\\.org/' + (type === 'movie' ? 'movie' : 'tv') + '/(\\d+)(?:[/?#-]|$)', 'i').exec(link)).find(Boolean);
      row.externalIds = {imdb:meta.id,tmdb:tmdb ? tmdb[1] : '',tmdbType:type === 'movie' ? 'movie' : 'tv'};
      row.mapping = {status:'mapped',method:'exact-normalized-original-title+first-release-year+type',searchUrl,metaUrl,canonicalTitle:meta.name,canonicalYear:metaYear(meta),metadataFetchedAt:detail.proof.fetchedAt};
      row.officialMeta = {id:meta.id,type:meta.type,name:meta.name,poster:meta.poster,background:meta.background,releaseInfo:meta.releaseInfo,description:meta.description,genres:meta.genres,imdbRating:meta.imdbRating};
    } catch { row.mapping = {status:'unmapped',reason:'public-metadata-request-unavailable',searchUrl}; }
  });
  return rows;
}

async function collect(outputDirectory) {
  const output = path.resolve(outputDirectory || 'russian-catalog-data');
  fs.mkdirSync(output, {recursive:true});
  const client = createClient(path.join(output, 'cache'));
  const filmixAll = await collectFilmix(client), seasonvarAll = await collectSeasonvar(client);
  fs.writeFileSync(path.join(output,'filmix-records.json'),JSON.stringify(filmixAll,null,2));
  fs.writeFileSync(path.join(output,'seasonvar-records.json'),JSON.stringify(seasonvarAll,null,2));
  const filmix = filmixAll.filter(row => row.type === 'movie').slice(0,20).concat(filmixAll.filter(row => row.type === 'series').slice(0,20)).sort((a,b) => a.listingPosition-b.listingPosition);
  const seasonvar = seasonvarAll.slice(0,40);
  await enrichSeasonvar(seasonvar, client);
  await mapRows(filmix, client); await mapRows(seasonvar, client);
  fs.writeFileSync(path.join(output,'filmix-mapped.json'),JSON.stringify(filmix,null,2));
  fs.writeFileSync(path.join(output,'seasonvar-mapped.json'),JSON.stringify(seasonvar,null,2));
  const summary = {generatedAt:new Date().toISOString(),filmix:{captured:filmixAll.length,examined:filmix.length,mapped:filmix.filter(row => row.mapping.status === 'mapped').length},seasonvar:{captured:seasonvarAll.length,examined:seasonvar.length,mapped:seasonvar.filter(row => row.mapping.status === 'mapped').length}};
  fs.writeFileSync(path.join(output,'summary.json'),JSON.stringify(summary,null,2));
  return summary;
}

module.exports = {collect,createClient,collectFilmix,collectSeasonvar,enrichSeasonvar,mapRows,seasonvarPage,normalize};
if (require.main === module) collect(process.argv[2]).then(summary => console.log(JSON.stringify(summary,null,2))).catch(error => { console.error(error.message); process.exitCode = 1; });
