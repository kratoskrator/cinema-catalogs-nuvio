'use strict';
const fs=require('node:fs');const path=require('node:path');
const {entry}=require('../src/catalog.cjs');
const inputs=process.argv.slice(2);
if(!inputs.length)throw new Error('Pass one or more mapped-record JSON files');
const records=[];const excluded={};
for(const input of inputs) {
 const values=JSON.parse(fs.readFileSync(input,'utf8'));
 if(!Array.isArray(values))throw new Error('Expected a mapped record array');
 for(const item of values) {
  const accepted=entry(item);
  if(!accepted){const reason=item.mappingStatus||item.mapping&&item.mapping.status||'invalid-or-blocked-record';excluded[reason]=(excluded[reason]||0)+1;continue;}
  records.push({source:accepted.source,type:accepted.preview.type,title:String(item.title),originalTitle:String(item.originalTitle||''),year:Number(accepted.preview.releaseInfo),imdbId:accepted.preview.id,tmdbId:accepted.tmdbId,poster:accepted.preview.poster,sourceUrl:accepted.sourceUrl,checkedAt:accepted.checkedAt,listingPosition:accepted.listingPosition,officialMetaUrl:'https://catalog.nuvio.tv/meta/'+accepted.preview.type+'/'+accepted.preview.id+'.json',mappingStatus:'exact-official-title-year-type',catalogYear:Number(accepted.preview.releaseInfo),canonicalTitle:String(item.catalogName||item.mapping&&item.mapping.canonicalTitle||''),mappingMethod:String(accepted.mappingMethod||''),hasEpisodes:item.hasEpisodes,publishedEpisodeCount:item.publishedEpisodeCount,episodeRouteCompatible:item.episodeRouteCompatible});
 }
}
if(!records.length)throw new Error('No valid website records; existing snapshot was preserved');
const target=path.join(__dirname,'../data/records.json');
fs.mkdirSync(path.dirname(target),{recursive:true});
fs.writeFileSync(target,JSON.stringify({generatedAt:new Date().toISOString(),records,excluded},null,2)+'\n');
console.log(JSON.stringify({acceptedBeforeDeduplication:records.length,excluded}));
