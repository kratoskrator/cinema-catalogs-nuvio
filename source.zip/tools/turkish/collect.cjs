'use strict';
const fs=require('node:fs');
const path=require('node:path');
const p=require('./lib.cjs');
const args=process.argv.slice(2);
function option(name,fallback){const i=args.indexOf(name);return i>=0&&args[i+1]?args[i+1]:fallback;}
const out=path.resolve(option('--out','catalog-data'));
const limit=Math.min(30,Math.max(1,Number(option('--limit','30'))||30));
const maxBytes=1024*1024;
const ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
fs.mkdirSync(out,{recursive:true});
const proof=[];
async function request(url,referer){
 const response=await fetch(url,{headers:{'User-Agent':ua,Accept:'text/html,application/xhtml+xml,*/*','Accept-Language':'tr-TR,tr;q=0.9,en;q=0.8',...(referer?{Referer:referer}:{})},signal:AbortSignal.timeout(15000)});
 const chunks=[];let bytes=0;for await(const chunk of response.body){bytes+=chunk.length;if(bytes>maxBytes)throw new Error('HTML exceeds1MiB limit');chunks.push(chunk);}
 const body=Buffer.concat(chunks).toString('utf8');
 const challenge=/<title[^>]*>\s*(?:Just a moment|Attention Required)|cf-browser-verification|cf-mitigated/i.test(body);
 return{status:response.status,url:response.url,body,bytes,challenge};
}
async function collect(source,id,home){
 const recordsFile=path.join(out,id+'-records.json');let landing;
 try{landing=await request(home);}catch(error){proof.push({source,sourceUrl:home,error:error.message});return;}
 fs.writeFileSync(path.join(out,id+'-home.html'),landing.body);
 proof.push({source,sourceUrl:home,finalUrl:landing.url,status:landing.status,bytes:landing.bytes,challenge:landing.challenge});
 if(landing.status!==200||landing.challenge){
  // Preserve a prior snapshot when the source is blocked, with explicit flags.
  if(fs.existsSync(recordsFile)){const old=JSON.parse(fs.readFileSync(recordsFile,'utf8'));old.forEach(item=>{item.cachedOnly=true;item.currentCatalogBlocked=true;});fs.writeFileSync(recordsFile,JSON.stringify(old,null,2));}
  else fs.writeFileSync(recordsFile,'[]\n');
  return;
 }
 const records=p.cards(source,landing.body,landing.url,limit);let index=0,blocked=false;
 async function worker(){while(index<records.length&&!blocked){const i=index++,item=records[i];try{const r=await request(item.sourceUrl,new URL(item.sourceUrl).origin+'/');proof.push({source,sourceUrl:item.sourceUrl,finalUrl:r.url,status:r.status,bytes:r.bytes,challenge:r.challenge});if(r.status!==200||r.challenge){if(r.status===403||r.challenge)blocked=true;continue;}fs.writeFileSync(path.join(out,id+'-detail-'+i+'.html'),r.body);item.checkedAt=new Date().toISOString();item.detailVerified=true;p.enrich(item,r.body);}catch(error){proof.push({source,sourceUrl:item.sourceUrl,error:error.message});}}}
 await Promise.all([worker(),worker()]);
 fs.writeFileSync(recordsFile,JSON.stringify(records,null,2));
 console.log(source+': '+records.length+' records; '+records.filter(x=>x.detailVerified).length+' verified detail pages.');
}
(async()=>{for(const target of [['DiziBOX','dizibox','https://www.dizibox.live/'],['DiziYou','diziyou','https://www.diziyou.one/'],['HDFilmCehennemi','hdfc','https://www.hdfilmcehennemi.nl/']])await collect(...target);fs.writeFileSync(path.join(out,'source-proof.json'),JSON.stringify({checkedAt:new Date().toISOString(),engine:'Node built-in fetch',requests:proof},null,2));console.log('Run map.cjs next. Source data: '+out);})().catch(error=>{console.error(error.message);process.exitCode=1;});
