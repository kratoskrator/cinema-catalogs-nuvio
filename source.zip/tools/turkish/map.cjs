'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const p=require('./lib.cjs');
const args=process.argv.slice(2),at=args.indexOf('--out');
const out=path.resolve(at>=0&&args[at+1]?args[at+1]:'catalog-data');
const cache=path.join(out,'official-cache');fs.mkdirSync(cache,{recursive:true});
const names=['dizibox','diziyou','hdfc'];
const groups=names.map(name=>{const file=path.join(out,name+'-records.json');return fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')).slice(0,30):[];});
async function get(url){const file=path.join(cache,crypto.createHash('sha256').update(url).digest('hex')+'.json');if(fs.existsSync(file))return JSON.parse(fs.readFileSync(file,'utf8')).body;const r=await fetch(url,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('Official catalog HTTP '+r.status);const body=await r.json();fs.writeFileSync(file,JSON.stringify({url,checkedAt:new Date().toISOString(),body},null,2));return body;}
async function cached(url){const file=path.join(cache,crypto.createHash('sha256').update(url).digest('hex')+'.json');if(fs.existsSync(file))return JSON.parse(fs.readFileSync(file,'utf8')).body;return get(url);}
async function map(item){const type=item.type==='tv'?'series':'movie',title=p.queryTitle(item);const search='https://catalog.nuvio.tv/catalog/'+type+'/popular-'+(type==='series'?'series':'movies')+'/search='+encodeURIComponent(title)+'.json';item.catalogSearchUrl=search;
 try{if(!item.imdbId){const data=await cached(search);const matches=(data.metas||[]).filter(m=>m.type===type&&/^tt\d{7,10}$/.test(m.id||'')&&p.normalize(m.name)===p.normalize(title)&&item.year&&p.releaseYear(m)===Number(item.year));if(matches.length!==1){item.mappingStatus=matches.length?'ambiguous-exact-match':'unmapped-title-year';return;}item.imdbId=matches[0].id;item.mappingStatus='exact-official-title-year-type';item.catalogName=matches[0].name;item.catalogYear=p.releaseYear(matches[0]);}
 const url='https://catalog.nuvio.tv/meta/'+type+'/'+item.imdbId+'.json',response=await cached(url),m=response.meta;if(!m||m.id!==item.imdbId||m.type!==type){item.mappingStatus='invalid-official-meta';item.imdbId=null;return;}const ids=(m.links||[]).map(l=>/themoviedb\.org\/(?:tv|movie)\/(\d+)/.exec(l.url||'')).filter(Boolean);item.tmdbId=ids.length===1?ids[0][1]:null;item.officialMetaUrl=url;item.officialPoster=m.poster||null;item.catalogMappingCheckedAt=new Date().toISOString();
 }catch(error){item.mappingStatus='mapping-request-failed';item.mappingError=error.message;}}
(async()=>{const items=groups.flat();let index=0;async function worker(){while(index<items.length)await map(items[index++]);}await Promise.all([worker(),worker()]);groups.forEach((group,i)=>fs.writeFileSync(path.join(out,names[i]+'-mapped-records.json'),JSON.stringify(group,null,2)));fs.writeFileSync(path.join(out,'all-mapped-records.json'),JSON.stringify(items,null,2));for(let i=0;i<groups.length;i++)console.log(names[i]+': '+groups[i].filter(x=>x.imdbId&&x.officialMetaUrl).length+' exact mappings of '+groups[i].length);})().catch(error=>{console.error(error.message);process.exitCode=1;});
