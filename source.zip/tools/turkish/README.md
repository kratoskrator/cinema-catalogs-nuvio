# Portable Turkish catalog collector

These MIT-licensed scripts require Node.js 20 or newer and use only Node built-ins. No package installation, external workspace files, account keys or browser sessions are required.

Run from this folder:

```sh
node collect.cjs --out catalog-data --limit 30
node map.cjs --out catalog-data
```

The maximum is 30 records per provider. The collector uses ordinary anonymous public HTTPS requests, a 1 MiB HTML response limit, 15-second deadlines, and two concurrent detail requests. It stops a source when access verification appears; it does not solve challenges or disable TLS checks. An existing snapshot is preserved and flagged when its source becomes blocked.

`collect.cjs` reads DiziBOX and DiziYou homepage series cards in site order, then their detail pages. HDFilmCehennemi is attempted normally; its current TV-style access is blocked, so its live card parser is not verified against a successful current homepage. A blocked source produces an empty initial snapshot, or preserves an existing snapshot with `cachedOnly`/`currentCatalogBlocked` flags.

`map.cjs` uses Nuvio's public catalog without account credentials. It requires one exact normalized title, year and media-type match, or a source-published IMDb ID. Ambiguous and unmatched titles are flagged, not guessed. Official search and metadata responses are cached by URL hash. Mapping runs at concurrency 2.

Output files:

- `dizibox-records.json`, `diziyou-records.json`, `hdfc-records.json`: source records.
- `*-mapped-records.json`, `all-mapped-records.json`: mapped records, preserving source order.
- `source-proof.json`, `*-home.html`, `*-detail-N.html`: provenance and source captures.
- `official-cache/`: public official lookup responses.

Records contain source, source URL, title, original title when published, year, movie/TV type, source poster, published IDs when available, and mapping status. Series also contain `hasEpisodes`, `publishedEpisodeCount`, `episodeRouteCompatible` and three example episode links. A published episode link is evidence of the website listing, not proof of video playback. `episodeRouteCompatible:false` means the existing provider's strict slug routing cannot follow the published aliases; exclude these from a catalog intended to work with that unchanged provider.

Import only records with a valid `imdbId` and `officialMetaUrl`; for series, prefer `hasEpisodes:true` and `episodeRouteCompatible:true`. A catalog title can still be unavailable or geo-blocked during playback.

The parsers were checked against all 60 captured successful detail pages used for the initial snapshot.
